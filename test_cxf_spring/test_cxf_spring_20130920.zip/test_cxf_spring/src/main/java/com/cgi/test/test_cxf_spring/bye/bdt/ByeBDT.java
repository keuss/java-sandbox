package com.cgi.test.test_cxf_spring.bye.bdt;

import java.util.List;

public class ByeBDT {

	private String name;
	private List<String> texts;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getTexts() {
		return texts;
	}
	public void setTexts(List<String> texts) {
		this.texts = texts;
	}
}

package com.cgi.test.test_cxf_spring.hello.bdt;

import java.util.List;

public class HelloBDT {

	private String name;
	private List<String> texts;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getTexts() {
		return texts;
	}
	public void setTexts(List<String> texts) {
		this.texts = texts;
	}
	
	

}

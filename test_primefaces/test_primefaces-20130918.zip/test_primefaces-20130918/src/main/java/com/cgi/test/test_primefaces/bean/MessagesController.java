package com.cgi.test.test_primefaces.bean;

import java.io.Serializable;
import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
  
@ManagedBean(name="ctrlMsg")
@RequestScoped
public class MessagesController implements Serializable {  
  
	private static final long serialVersionUID = 1L;
	
	/** LOGGER for the class. */
	private static final Logger LOGGER = LoggerFactory.getLogger(MessagesController.class);
	
	
    public void testListener() {
    	LOGGER.debug("Call for MessagesController.testListener at : " + new Date() );
    }
    
    public void addInfo() {  
    	LOGGER.debug("Call for MessagesController.addInfo at : " + new Date() );
    	//TODO si donne vide ... ?
        FacesContext.getCurrentInstance().addMessage("userFrom:id", new FacesMessage(FacesMessage.SEVERITY_INFO, "Sample info message", "PrimeFaces rocks!"));  
    }  
  
}

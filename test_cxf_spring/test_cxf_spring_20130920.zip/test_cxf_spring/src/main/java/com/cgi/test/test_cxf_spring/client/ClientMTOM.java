package com.cgi.test.test_cxf_spring.client;

import java.io.File;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cgi.test.test_cxf_spring.mtom.bdt.DataBDT;
import com.cgi.test.test_cxf_spring.mtom.itf.MTOMService;

public class ClientMTOM {


	private ClientMTOM() {
	}

	public static void main(String args[]) throws Exception {

		// START SNIPPET: client
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"client-beans.xml"});

		//HelloService
		MTOMService mtomClient = (MTOMService)context.getBean("mtomClient");

		System.out.println("starting  ClientMTOM ...");
		File myXmlFile  = new File("d:/workspace_test_2012/test_cxf_spring/file.xml");
		System.out.println("myXmlFile : " + myXmlFile.getAbsolutePath());

		DataSource source = new FileDataSource(myXmlFile);
		DataHandler handler = new DataHandler(source);
		DataBDT file = new DataBDT(handler, "filetest");
		
		String response = mtomClient.sendData(file);
		System.err.println("response from WS : [" + response + "]");

		System.exit(0);
		// END SNIPPET: client
	}

}
